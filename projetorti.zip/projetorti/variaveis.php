<?php

$atuador1_valor = file_get_contents('api/files/atuador1/valor.txt');
$atuador2_valor = file_get_contents('api/files/atuador2/valor.txt');
$atuador3_valor = file_get_contents('api/files/atuador3/valor.txt');

$atuador1_hora = file_get_contents('api/files/atuador1/hora.txt');
$atuador2_hora = file_get_contents('api/files/atuador2/hora.txt');
$atuador3_hora = file_get_contents('api/files/atuador3/hora.txt');

$atuador1_data = file_get_contents('api/files/atuador1/data.txt');
$atuador2_data = file_get_contents('api/files/atuador2/data.txt');
$atuador3_data = file_get_contents('api/files/atuador3/data.txt');

$sensor1_valor = file_get_contents('api/files/sensor1/valor.txt');
$sensor2_valor = file_get_contents('api/files/sensor2/valor.txt');
$sensor3_valor = file_get_contents('api/files/sensor3/valor.txt');

$sensor1_hora = file_get_contents('api/files/sensor1/hora.txt');
$sensor2_hora = file_get_contents('api/files/sensor2/hora.txt');
$sensor3_hora = file_get_contents('api/files/sensor3/hora.txt');

$sensor1_data = file_get_contents('api/files/sensor1/data.txt');
$sensor2_data = file_get_contents('api/files/sensor2/data.txt');
$sensor3_data = file_get_contents('api/files/sensor3/data.txt');