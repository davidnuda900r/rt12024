<?php
// Dados que você deseja enviar para a API
$data = array(
    'nome' => 'sensor1',
    'valor' => '84',
    // Adicione mais campos conforme necessário
);

// URL da API que você está enviando o POST
$url = 'http://localhost/projetorti/api/api.php';

// Inicializa o cURL
$curl = curl_init($url);

// Configura as opções do cURL
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

// Executa a requisição e obtém a resposta
$response = curl_exec($curl);

// Verifica se houve algum erro na requisição
if(curl_errno($curl)){
    // Trata o erro
    $error_message = curl_error($curl);
    // Aqui você pode tratar o erro de acordo com sua lógica de aplicação
    echo "Erro ao enviar requisição: $error_message";
}

// Fecha a conexão cURL
curl_close($curl);

// Trata a resposta da API
if ($response) {
    // Faça o que precisar com a resposta da API
    echo "Resposta da API: $response";
} else {
    // Trate o caso em que não há resposta
    echo "Não foi possível obter uma resposta da API";
}
?>